<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
  <title>Shopping Mall</title>
  <link rel="stylesheet" href="css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>

<header>
  <nav>
    <a href="index.php" class="logo">
      <img src="images/logo.png" alt="Shopping Mall Logo" />
    </a>
    <div class="nav-links">
      <a href="index.php">Home</a>
      <a href="products.php">Products</a>
      <a href="cart.php">Cart</a>
      <?php if (isset($_SESSION['user_id'])): ?>
        <span style="color:white;">Welcome, <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
      <?php endif; ?>
    </div>
  </nav>
</header>
