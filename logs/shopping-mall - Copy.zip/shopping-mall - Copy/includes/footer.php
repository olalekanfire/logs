<hr>
<footer>
  <div class="footer-container">
    <p>&copy; <?= date("Y") ?> Shopping Mall. All rights reserved.</p>
    <p>Contact: olamilekan@gmall.com</p>
  </div>
</footer>

