<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="container">
<h2>Product List</h2>
<p>Welcome to our online store! Browse our collection of products below.</p>
<p>We offer a wide range of products to suit your needs. From electronics to clothing, we have something for everyone.</p>
</div>

<?php
if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($row = $result->fetch_assoc()) {
?>
  <h2><?= $row['name'] ?></h2>
  <img src="images/<?= $row['image'] ?>" style="width:300px;"><br><br>
  <p><?= $row['description'] ?></p>
  <p>Price: $<?= number_format($row['price'], 2) ?></p>
  <form method="POST" action="cart.php">
    <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
    <input type="number" name="quantity" value="1" min="1" max="<?= $row['stock'] ?>"><br><br>
    <button type="submit" name="add_to_cart">Add to Cart</button>
  </form>
<?php
  if ($result->num_rows == 0) {
      echo "<p>No products found.</p>";
     } else {
      echo "<p>Found " . $result->num_rows . " products.</p>";
    }
  } else {
    echo "<p>Product not found.</p>";
  }
  $stmt->close();
} else {
  echo "<p>No product selected.</p>";
}
?>

<div style="display: flex; flex-wrap: wrap; gap: 20px;">

<?php
$result = $conn->query("SELECT * FROM products");


while ($row = $result->fetch_assoc()):
?>
  <div class="container">
    <img src="images/<?= $row['image'] ?>" alt="<?= $row['name'] ?>" style="width:100%; height:150px;"><br>
    <h3><?= $row['name'] ?></h3>
    <p>$<?= number_format($row['price'], 2) ?></p>
    <form method="POST" action="cart.php">
  <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
  <input type="number" name="quantity" value="1" min="1" max="<?= $row['stock'] ?>" style="width: 50px;">
  <button type="submit" name="add_to_cart">Add to Cart</button>
</form>
  </div>
<?php endwhile; ?>

  <!-- more cards -->
<!-- <div class="product-grid">
  <div class="product-card">Product 1</div>
  <div class="product-card">Product 2</div>
</div> -->


</div>






<?php include 'includes/footer.php'; ?>
