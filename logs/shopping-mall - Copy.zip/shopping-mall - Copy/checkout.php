<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="container">
  
<h2>Checkout</h2>
<p>Please fill in your details to complete the purchase.</p>
</div>

<?php
// session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if (empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty. <a href='products.php'>Shop now</a></p>";
    include 'includes/footer.php';
    exit;
}

if (isset($_POST['checkout'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);

    if ($name && $email) {
        $total = 0;

        foreach ($_SESSION['cart'] as $product_id => $qty) {
            $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            $total += $product['price'] * $qty;
        }

        // Insert into orders
        $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, total) VALUES (?, ?, ?)");
        $stmt->bind_param("ssd", $name, $email, $total);
        $stmt->execute();
        $order_id = $stmt->insert_id;

        // Insert order items
        foreach ($_SESSION['cart'] as $product_id => $qty) {
            $stmt = $conn->prepare("SELECT price FROM products WHERE id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            $price = $product['price'];

            $stmt = $conn->prepare("INSERT INTO orders_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $order_id, $product_id, $qty, $price);
            $stmt->execute();
        }

        // Send email confirmation
        $to = $email;
        $subject = "Order Confirmation - Order #$order_id";
        $message = "Hi $name,\n\nThank you for your order!\nYour order ID is $order_id.\nTotal: $$total\n\n- Shopping Mall";
        $headers = "From: noreply@yourdomain.com";

        // mail($to, $subject, $message, $headers);

        // Clear cart
        $_SESSION['cart'] = [];

        echo "<h2>Order Placed Successfully!</h2>";
        echo "<p>Thank you, <strong>$name</strong>. Your order ID is <strong>#$order_id</strong>.</p>";
        include 'includes/footer.php';
        exit;
    } else {
        echo "<p style='color:red;'>Please fill in all fields.</p>";
    }
}
?>


<h2>Checkout</h2>

<form method="post" action="checkout.php">
  <label>Name:</label>
  <input type="text" name="name" required><br>

  <label>Email:</label>
  <input type="email" name="email" required><br>

  <input type="submit" name="checkout" value="Place Order">
</form>


<?php include 'includes/footer.php'; ?>


