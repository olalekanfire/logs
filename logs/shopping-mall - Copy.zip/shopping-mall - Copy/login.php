<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>
<!-- <?php session_start(); ?> -->

<div class="container">
<h2>Login</h2>
<form method="POST" action="">
  <input type="email" name="email" placeholder="Email" required><br><br>
  <input type="password" name="password" placeholder="Password" required><br><br>
  <button type="submit" name="login">Login</button>
</form>
</div>


<?php
if (isset($_POST['login'])) {
  $email = $_POST['email'];
  $password = $_POST['password'];

  $stmt = $conn->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $stmt->store_result();

  if ($stmt->num_rows == 1) {
    $stmt->bind_result($id, $name, $hashed_password, $role);
    $stmt->fetch();

    if (password_verify($password, $hashed_password)) {
      $_SESSION['user_id'] = $id;
      $_SESSION['name'] = $name;
      $_SESSION['role'] = $role;

      echo "<p>Login successful! Welcome, $name.</p>";
      echo "<script>window.location.href='index.php';</script>";
    } else {
      echo "<p>Invalid password.</p>";
    }
  } else {
    echo "<p>User not found.</p>";
  }

  $stmt->close();
}
?>


<?php include 'includes/footer.php'; ?>
