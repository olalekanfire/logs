<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="container">
<h2>Welcome to the Shopping Mall</h2>
<p>Shop quality products at the best prices.</p>
<p><a href="products.php">Browse Products</a></p>
</div>


<?php include 'includes/footer.php'; ?>
