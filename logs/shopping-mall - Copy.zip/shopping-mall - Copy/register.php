<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="container">
<h2>Register</h2>
<form method="POST" action="">
  <input type="text" name="name" placeholder="Full Name" required><br><br>
  <input type="email" name="email" placeholder="Email" required><br><br>
  <input type="password" name="password" placeholder="Password" required><br><br>
  <button type="submit" name="register">Register</button>
</form>
</div>

<?php
if (isset($_POST['register'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $name, $email, $password);

  if ($stmt->execute()) {
    echo "<p>Registration successful! <a href='login.php'>Login here</a>.</p>";
  } else {
    echo "<p>Error: Email already exists.</p>";
  }

  $stmt->close();
}
?>


<?php include 'includes/footer.php'; ?>


