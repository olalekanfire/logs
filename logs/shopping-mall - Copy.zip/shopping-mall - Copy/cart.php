<?php
include 'includes/conn.php';
include 'includes/header.php';
?>
<div class="container">
<h2>Your Shopping Cart</h2>
<p>Your cart contains the following items:</p>


<?php
// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Handle add to cart request
if (isset($_POST['add_to_cart'])) {
    $product_id = intval($_POST['product_id']);
    $quantity = intval($_POST['quantity']);

    // If product already in cart, increase quantity
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        $_SESSION['cart'][$product_id] = $quantity;
    }

    echo "<p>Product added to cart! <a href='cart.php'>View Cart</a></p>";
}
?>

<?php
if (empty($_SESSION['cart'])) {
    echo "<p>Your cart is empty.</p>";
} else {
    echo "<table border='1' cellpadding='10'>
            <tr>
                <th>Product</th><th>Price</th><th>Quantity</th><th>Total</th>
            </tr>";

    $total = 0;

    foreach ($_SESSION['cart'] as $product_id => $qty) {
        $stmt = $conn->prepare("SELECT name, price FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();

        $name = $product['name'];
        $price = $product['price'];
        $line_total = $price * $qty;
        $total += $line_total;

        echo "<tr>
                <td>$name</td>
                <td>$$price</td>
                <td>$qty</td>
                <td>$$line_total</td>
              </tr>";
    }

    echo "<tr><td colspan='3'><strong>Total</strong></td><td><strong>$$total</strong></td></tr>";
    echo "</table><br>";

    echo "<a href='checkout.php'>Proceed to Checkout</a>";
}
?>
<?php
// Handle quantity update

if (isset($_POST['update_cart']) && isset($_POST['quantities']) && is_array($_POST['quantities'])) {
    foreach ($_POST['quantities'] as $product_id => $qty) {
        $qty = intval($qty);
        if ($qty <= 0) {
            unset($_SESSION['cart'][$product_id]);
        } else {
            $_SESSION['cart'][$product_id] = $qty;
        }
    }
    echo "<p>Cart updated.</p>";
}

if (isset($_POST['clear_cart'])) {
    unset($_SESSION['cart']);
    echo "<p>Cart cleared.</p>";
}

// Handle remove
if (isset($_GET['remove'])) {
    $remove_id = intval($_GET['remove']);
    unset($_SESSION['cart'][$remove_id]);
    echo "<p>Item removed from cart.</p>";
}
?>
<form method="POST" action="">
    <input type="submit" name="update_cart" value="Update Cart">
    <input type="submit" name="clear_cart" value="Clear Cart">
</form>
</div>

<?php include 'includes/footer.php'; ?>

