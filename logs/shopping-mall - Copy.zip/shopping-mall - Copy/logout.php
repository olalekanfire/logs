<?php include 'includes/conn.php'; ?>
<?php include 'includes/header.php'; ?>

<?php
session_start();
session_unset(); // Clear all session variables
session_destroy(); // Destroy the session
header("Location: login.php"); // Redirect to login or home
exit;
?>

<?php include 'includes/footer.php'; ?>
